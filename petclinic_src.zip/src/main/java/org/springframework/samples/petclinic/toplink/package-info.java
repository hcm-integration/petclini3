
/**
 *
 * The classes in this package provide support for using the TopLink
 * implementation with PetClinic's EntityManagerClinic.
 * 
 *
 */
package org.springframework.samples.petclinic.toplink;

