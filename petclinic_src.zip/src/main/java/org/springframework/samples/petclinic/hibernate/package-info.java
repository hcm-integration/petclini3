
/**
 *
 * The classes in this package represent the Hibernate implementation
 * of PetClinic's persistence layer.
 *
 */
package org.springframework.samples.petclinic.hibernate;

